<?php
/**
 * CAZORLA PLANNING 2026 - API Backend v2
 * 
 * Los datos se guardan en MySQL. Puedes actualizar index.html
 * tantas veces como quieras sin perder datos.
 * La tabla se crea sola y se migra automáticamente.
 */

$DB_HOST = 'localhost';
$DB_NAME = 'u919343704_cazorla_planni';
$DB_USER = 'u919343704_info';
$DB_PASS = 'Gallito9431%';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    try {
        $pdo = new PDO("mysql:host=$DB_HOST;charset=utf8mb4", $DB_USER, $DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$DB_NAME` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `$DB_NAME`");
    } catch (PDOException $e2) {
        echo json_encode(['error' => 'DB connection failed', 'detail' => $e2->getMessage()]); exit;
    }
}

// Auto-migrate: create table + version column
$pdo->exec("CREATE TABLE IF NOT EXISTS `planning_data` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `data` LONGTEXT NOT NULL,
    `version` INT DEFAULT 1,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Add version column if missing (migration)
try { $pdo->exec("ALTER TABLE `planning_data` ADD COLUMN `version` INT DEFAULT 1"); } catch(Exception $e) {}

$count = $pdo->query("SELECT COUNT(*) FROM `planning_data`")->fetchColumn();
if ($count == 0) {
    $pdo->exec("INSERT INTO `planning_data` (`data`, `version`) VALUES ('[]', 1)");
}

$action = $_GET['action'] ?? '';

if ($action === 'load') {
    $stmt = $pdo->query("SELECT `data`, `version`, `updated_at` FROM `planning_data` ORDER BY `id` DESC LIMIT 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(['ok' => true, 'data' => json_decode($row['data']), 'version' => (int)$row['version'], 'updated' => $row['updated_at']]);
    exit;
}

if ($action === 'save') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input || !isset($input['data'])) { echo json_encode(['error' => 'Invalid data']); exit; }
    $encoded = json_encode($input['data'], JSON_UNESCAPED_UNICODE);
    $version = isset($input['version']) ? (int)$input['version'] : 1;
    $stmt = $pdo->prepare("UPDATE `planning_data` SET `data` = ?, `version` = ? WHERE `id` = (SELECT `id` FROM (SELECT `id` FROM `planning_data` ORDER BY `id` DESC LIMIT 1) AS t)");
    $stmt->execute([$encoded, $version]);
    echo json_encode(['ok' => true, 'version' => $version, 'updated' => date('Y-m-d H:i:s')]);
    exit;
}

if ($action === 'check') {
    $since = $_GET['since'] ?? '';
    $stmt = $pdo->query("SELECT `updated_at`, `version` FROM `planning_data` ORDER BY `id` DESC LIMIT 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(['ok' => true, 'updated' => $row['updated_at'], 'version' => (int)$row['version'], 'changed' => (!$since || $row['updated_at'] > $since)]);
    exit;
}

echo json_encode(['ok' => true, 'message' => 'Cazorla Planning API v2', 'actions' => ['load','save','check']]);
