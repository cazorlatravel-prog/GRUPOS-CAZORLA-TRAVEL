const CACHE='cazorla-v5';
const ASSETS=['./','./styles.css','./app.js','./manifest.json'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  // Always go network-first for API calls
  if(e.request.url.includes('api.php')){e.respondWith(fetch(e.request));return}
  e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)))
});
